"use client";

import { useFormContext, useWatch } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { InvoiceFormValues } from "../../types/invoice-form.types";

const METHODS = ["Cash", "Bank Transfer", "UPI", "Card", "Cheque", "Other"] as const;
const STATUSES = [
  { value: "PENDING", label: "Pending" },
  { value: "PARTIAL", label: "Partial" },
  { value: "PAID", label: "Paid" },
  { value: "OVERDUE", label: "Overdue" },
] as const;

/**
 * Payment information — invoice-only section.
 * UI style matches quotation SalesSectionCard fields.
 */
export function InvoicePaymentSection() {
  const { register, setValue, control } = useFormContext<InvoiceFormValues>();

  const paymentStatus =
    useWatch({ control, name: "paymentStatus" }) ?? "PENDING";
  const paymentMethod =
    useWatch({ control, name: "paymentMethod" }) ?? "Cash";

  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <div className="space-y-1.5">
        <Label className="text-xs text-slate-600">Payment status</Label>
        <Select
          value={String(paymentStatus)}
          onValueChange={(v) =>
            setValue("paymentStatus", v as InvoiceFormValues["paymentStatus"], {
              shouldDirty: true,
            })
          }
        >
          <SelectTrigger className="h-9">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            {STATUSES.map((s) => (
              <SelectItem key={s.value} value={s.value}>
                {s.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-1.5">
        <Label className="text-xs text-slate-600">Payment method</Label>
        <Select
          value={String(paymentMethod || "Cash")}
          onValueChange={(v) =>
            setValue("paymentMethod", v, { shouldDirty: true })
          }
        >
          <SelectTrigger className="h-9">
            <SelectValue placeholder="Method" />
          </SelectTrigger>
          <SelectContent>
            {METHODS.map((m) => (
              <SelectItem key={m} value={m}>
                {m}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-1.5">
        <Label className="text-xs text-slate-600">Paid amount (₹)</Label>
        <Input
          type="number"
          min={0}
          step="0.01"
          className="h-9"
          {...register("paidAmount", { valueAsNumber: true })}
        />
      </div>

      <div className="space-y-1.5">
        <Label className="text-xs text-slate-600">Payment date</Label>
        <Input
          type="date"
          className="h-9"
          {...register("paymentDate")}
        />
      </div>

      <div className="space-y-1.5 sm:col-span-2">
        <Label className="text-xs text-slate-600">Transaction / reference ID</Label>
        <Input
          className="h-9"
          placeholder="Optional"
          {...register("transactionId")}
        />
      </div>
    </div>
  );
}
