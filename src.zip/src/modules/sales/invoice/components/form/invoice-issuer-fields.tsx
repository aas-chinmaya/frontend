"use client";

import {
  BusinessDetailsFields,
  BUSINESS_FIELD_NAMES,
} from "@/modules/sales/shared/components/party/business-details-fields";

/** Invoice issuer block — reuses shared BusinessDetailsFields */
export function InvoiceIssuerFields() {
  return (
    <BusinessDetailsFields
      fields={BUSINESS_FIELD_NAMES}
      title="From (your business)"
      showBankSection
    />
  );
}
